// MỘT chỗ duy nhất giữ thông tin liên hệ. Đổi số hoặc email chỉ cần sửa file này.
// zalo/call: số nhận tin Zalo và cuộc gọi trên mọi nút (D-066: số trong config web giá).
// officePhone, address: theo profile 2026, chỉ hiển thị ở phần Liên hệ.
export const SITE = {
  name: 'Đất Cảng Agency',
  tagline: 'Giải pháp Marketing',
  url: 'https://datcanggroup.vn',
  zalo: '0977103939',
  call: '0977103939',
  email: 'datcangagency@gmail.com',
  officePhone: '035 984 5261',
  address: 'Đất Cảng Building Lô 175 Khu Tái Định Cư Tam Kỳ, An Biên, Hải Phòng',
  facebook: 'https://www.facebook.com/DatCangAgency',
  messenger: 'https://m.me/DatCangAgency',
  // Bản đồ: địa điểm "ĐẤT CẢNG AGENCY BUILDING" trên Google Maps (anh Linh gửi link 26/11/2026).
  mapShare: 'https://maps.app.goo.gl/FraGdic5pc6UP7kS9',
  mapEmbed: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3729.233431881991!2d106.67879029999999!3d20.822278200000003!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x314a71006f1fad77%3A0x8ef35ba7bbb98842!2zxJDhuqRUIEPhuqJORyBBR0VOQ1kgQlVJTERJTkc!5e0!3m2!1svi!2s!4v1795668666963!5m2!1svi!2s',
};

// "0977103939" -> "0977 103 939"
export const fmtPhone = (n) => n.replace(/(\d{4})(\d{3})(\d{3})/, '$1 $2 $3');
export const telHref = (n) => 'tel:' + n.replace(/\D/g, '');
export const zaloHref = (n) => 'https://zalo.me/' + n.replace(/\D/g, '');

export const NAV = [
  { href: '/', label: 'Trang chủ' },
  { href: '/ve-chung-toi/', label: 'Về chúng tôi' },
  { href: '/dich-vu/', label: 'Dịch vụ' },
  { href: '/du-an/', label: 'Dự án' },
  { href: '/bang-gia/', label: 'Bảng giá' },
  { href: '/lien-he/', label: 'Liên hệ' },
];
