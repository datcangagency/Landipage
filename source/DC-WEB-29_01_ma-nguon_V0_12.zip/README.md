# Website Đất Cảng Agency (datcanggroup.vn)

Website tĩnh dựng bằng Astro, phát hành lên GitHub Pages bằng GitHub Actions (`.github/workflows/deploy.yml`).

## Sửa gì ở đâu

| Việc | File |
|---|---|
| Đổi số Zalo, số Gọi, email, địa chỉ | `src/data/site.js` (một chỗ duy nhất) |
| Nội dung 5 trụ cột dịch vụ | `src/data/pillars.js` |
| Nội dung 6 dự án tiêu biểu, logo khách hàng | `src/data/cases.js` |
| Câu chuyện, tầm nhìn, đội ngũ, quy trình | `src/data/story.js` |
| Giá (bản sao cố định bảng giá V6.1) | `src/scripts/price-data.js` (sinh tự động từ bảng giá, không sửa tay) |
| Giao diện | `src/styles/global.css` (site), `src/styles/price.css` (công cụ tính giá) |
| Ảnh | `public/img/` |

## Chạy thử trên máy

Cần Node 22.23.4 trở lên.

```
npm install
npm run dev      # xem thử tại http://localhost:4321
npm run build    # sinh thư mục dist/
```

## Phát hành

- Đẩy lên nhánh `website-v2`: Actions chỉ dựng thử, không phát hành.
- Gộp vào `main`: Actions dựng và phát hành lên https://datcanggroup.vn (tên miền khai ở `public/CNAME`).

## Lưu ý

- Công cụ tính giá là bản sao cố định của bảng giá V6.1 (06/11/2026). Khi giá đổi, thay `src/scripts/price-data.js` bằng bản mới rồi đẩy lên `main`.
- Không đưa dữ liệu khách hàng, số tài khoản, khóa API hay thông tin nội bộ vào repo này (repo công khai).
- Trang `/kien-thuc/` và `/tuyen-dung/` đang là khung, ẩn khỏi menu và có `noindex`.
