// Đọc dữ liệu giá V6.1 lúc build (bản sao cố định: src/scripts/price-data.js) để hiện "từ ... đ" trên trang dịch vụ.
import fs from 'node:fs';
import path from 'node:path';
const src = fs.readFileSync(path.join(process.cwd(), 'src/scripts/price-data.js'), 'utf8');
const w = {};
new Function('window', src)(w);
export const PRICE = w.PRICE_DATA;
export const vnd = (n) => new Intl.NumberFormat('vi-VN').format(n) + 'đ';
export function lineInfo(name) {
  const l = PRICE.lines.find((x) => x.name === name);
  if (!l) return null;
  const pr = l.opts.filter((o) => typeof o.price === 'number' && o.price > 0 && o.kind !== 'upgrade');
  const min = pr.length ? pr.reduce((a, b) => (a.price <= b.price ? a : b)) : null;
  return { name: l.name, lead: l.lead, count: l.opts.length, min: min ? { price: min.price, unit: min.unit } : null, contact: !min };
}
