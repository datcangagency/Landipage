// MỘT chỗ duy nhất giữ thông tin liên hệ. Đổi số hoặc email chỉ cần sửa file này.
// zalo/call: số nhận tin Zalo và cuộc gọi trên mọi nút (D-066: số trong config web giá).
// officePhone, address: theo profile 2026, chỉ hiển thị ở phần Liên hệ.
export const SITE = {
  name: 'Đất Cảng Agency',
  tagline: 'Giải pháp Marketing',
  url: 'https://datcanggroup.vn',
  zalo: '0977103939',
  call: '0977103939',
  email: 'datcangagency@gmail.com',
  officePhone: '035 984 5261',
  address: 'Đất Cảng Building Lô 175 Khu Tái Định Cư Tam Kỳ, An Biên, Hải Phòng',
  facebook: 'https://www.facebook.com/DatCangAgency',
  messenger: 'https://m.me/DatCangAgency',
  mapShare: 'https://share.google/uFZQNXSzEL5eFywhI',
  mapEmbed: 'https://www.google.com/maps?q=' + encodeURIComponent('Đất Cảng Building Lô 175 Khu Tái Định Cư Tam Kỳ, An Biên, Hải Phòng') + '&hl=vi&z=16&output=embed',
};

// "0977103939" -> "0977 103 939"
export const fmtPhone = (n) => n.replace(/(\d{4})(\d{3})(\d{3})/, '$1 $2 $3');
export const telHref = (n) => 'tel:' + n.replace(/\D/g, '');
export const zaloHref = (n) => 'https://zalo.me/' + n.replace(/\D/g, '');

export const NAV = [
  { href: '/', label: 'Trang chủ' },
  { href: '/ve-chung-toi/', label: 'Về chúng tôi' },
  { href: '/dich-vu/', label: 'Dịch vụ' },
  { href: '/du-an/', label: 'Dự án' },
  { href: '/bang-gia/', label: 'Bảng giá' },
  { href: '/lien-he/', label: 'Liên hệ' },
];
