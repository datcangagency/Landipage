// Nội dung theo profile 2026 (tr. 5–15). Giữ nguyên ý, chỉ sửa lỗi chính tả hiển nhiên.
export const STORY = [
  { yr: '2023', sub: 'Khởi nguồn từ', title: '3 người trẻ và một câu hỏi lớn',
    img: ['story-2023-a'], img2: ['story-2023-b', 'story-2023-c'], alt: 'Những ngày đầu của đội ngũ Đất Cảng đi quay dự án',
    body: ['Năm 2023, giữa một thị trường Marketing tại Hải Phòng đang từng ngày thay đổi, có 3 người trẻ cùng đau đáu về một điều: tại sao những doanh nghiệp, thương hiệu của thành phố này có sản phẩm tốt, có câu chuyện riêng, có tiềm năng để phát triển, nhưng đôi khi vẫn chưa tìm được một cách làm Marketing thực sự phù hợp?',
      'Họ bắt đầu nói với nhau về một điều tưởng như rất lớn: nếu có một đội ngũ Marketing đủ hiểu Hải Phòng, đủ hiểu doanh nghiệp địa phương và đủ quyết tâm để đi cùng khách hàng đến tận cùng bài toán kinh doanh, thì sao?',
      'Đó là cách câu chuyện về Đất Cảng bắt đầu. Không phải từ một văn phòng đẹp, một đội ngũ đông hay những con số ấn tượng. Chỉ từ 3 con người, một niềm tin và rất nhiều điều chưa biết phía trước.',
      'Nhưng có một điều họ tin: Marketing không thể chỉ là những bài đăng đẹp, những con số tương tác hay một chiến dịch tạo được tiếng vang trong vài ngày. Marketing, sau cùng, phải giúp một doanh nghiệp tốt hơn.'] },
  { yr: '2025', sub: 'Tháng 9 · Từ ý tưởng', title: 'Trở thành một cái tên',
    img: ['shopfront-2025'], img2: ['office-2025-a', 'office-2025-b', 'office-2025-c'], alt: 'Văn phòng đầu tiên của Đất Cảng Agency',
    body: ['Hai năm sau, tháng 9/2025, điều từng chỉ tồn tại trong những cuộc trò chuyện năm 2023 chính thức trở thành một cái tên: Đất Cảng Agency.',
      'Những ngày đầu tiên, Đất Cảng chỉ có 4 người trong một căn phòng 40m². Một không gian nhỏ đến mức mọi người gần như có thể nghe thấy tiếng bàn phím của nhau, nhìn thấy nhau làm việc mỗi ngày và cùng chia sẻ với nhau cả những niềm vui rất nhỏ lẫn những áp lực rất lớn.',
      'Không có quá nhiều nguồn lực để bắt đầu, nên thứ duy nhất chúng tôi có thể lựa chọn là làm thật tốt những gì nằm trong khả năng của mình. Những cái gật đầu gửi gắm đầu tiên của khách hàng khi ấy không chỉ là một cơ hội làm việc, mà là nguồn sinh khí thiêng liêng sưởi ấm đội ngũ cả một chặng đường dài.',
      'Chúng tôi hiểu rằng, mỗi lần khách hàng đặt thương hiệu, ngân sách và kỳ vọng của họ vào tay mình, Đất Cảng phải có trách nhiệm trả lại nhiều hơn những gì họ đã trao.',
      'Tháng 11 năm 2025, Đất Cảng đón nhận bước chuyển mình đầy cảm xúc khi dịch chuyển sang một mái nhà mới rộng mở hơn, quy tụ gần 20 tâm hồn cùng chung nhịp đập nhiệt huyết. Lớn lên không chỉ là có thêm người, thêm dự án hay thêm khách hàng. Lớn lên còn có nghĩa là phải biết chịu trách nhiệm lớn hơn.'] },
  { yr: '2026', sub: 'Tháng 8', title: 'Người đồng hành chiến lược',
    img: ['office-2026'], img2: [], alt: 'Văn phòng làm việc của Đất Cảng Agency năm 2026',
    quote: 'Không dừng lại ở những chiến dịch Marketing, Đất Cảng định vị mình là điểm tựa chiến lược gắn liền với sự sống còn và thịnh vượng của đối tác.',
    body: ['Đến tháng 8 năm 2026, Đất Cảng bước vào điểm ngoặt trưởng thành sâu sắc về tư duy. Chúng tôi nhận ra sứ mệnh của mình đã vượt xa khỏi định danh của một đơn vị làm dịch vụ Marketing Online thuần túy.',
      'Đất Cảng chọn trở thành Người Đồng Hành Chiến Lược: một điểm tựa thực chiến đi qua từng thăng trầm, gắn liền với sự sống còn và thịnh vượng của mỗi doanh nghiệp.',
      'Bởi chúng tôi tin rằng, phía sau mỗi thương hiệu là một người chủ đang đặt vào đó thời gian, tiền bạc, công sức và rất nhiều kỳ vọng. Phía sau mỗi chiến dịch là một bài toán kinh doanh cần được giải quyết. Và phía sau mỗi con số là một câu chuyện về sự sống còn, tăng trưởng và tương lai của doanh nghiệp.'] },
];
export const VISION = 'Trở thành Agency Marketing chiến lược và thực thi uy tín hàng đầu, là người đồng hành đáng tin cậy của các doanh nghiệp trên hành trình xây dựng thương hiệu, chuẩn hóa hệ thống marketing của doanh nghiệp và tạo dựng sự tăng trưởng bền vững.';
export const MISSIONS = [
  { to: 'Đối với khách hàng & doanh nghiệp', text: 'Biến chiến lược thành hành động. Biến nguồn lực Marketing thành giá trị tăng trưởng.' },
  { to: 'Đối với nhân sự & đội ngũ', text: 'Kiến tạo đội ngũ Marketing thực chiến, chuyên môn và bản lĩnh.' },
  { to: 'Đối với xã hội & cộng đồng', text: 'Góp phần nâng cao năng lực Marketing cho cộng đồng doanh nghiệp địa phương.' },
];
export const VALUES = ['Trách nhiệm', 'Sáng tạo', 'Hiệu quả', 'Uy tín'];
export const TEAM = [
  ['CEO', 'Định hướng chiến lược và điều hành tổng thể'], ['Project Manager', 'Điều phối dự án, tiến độ và phân bổ công việc'],
  ['QA/QC', 'Kiểm soát chất lượng đầu ra'], ['Sale', 'Phát triển khách hàng và tư vấn giải pháp'],
  ['Content', 'Xây dựng ý tưởng, nội dung và thông điệp'], ['Design', 'Phát triển hình ảnh và ấn phẩm truyền thông'],
  ['Media', 'Sản xuất hình ảnh, video và hậu kỳ'], ['Kế toán', 'Quản lý tài chính và chứng từ'],
];
export const CAPS = [
  { t: 'Sản xuất nội dung', d: 'Chiến lược nội dung, social media, kịch bản video', img: 'cap-content' },
  { t: 'Thiết kế hình ảnh', d: 'Social Media, Key Visual, Banner, Poster, POSM', img: 'cap-design' },
  { t: 'Video & Media', d: 'Quay chụp, video thương hiệu, video ngắn, livestream', img: 'cap-video' },
  { t: 'Phối hợp triển khai', d: 'Chủ động nhiều hạng mục đồng thời, linh hoạt theo từng dự án', img: 'cap-event' },
];
export const PROCESS = [
  ['Khách gửi yêu cầu', 'Tiếp nhận thông tin ban đầu, mục tiêu và thực trạng của khách hàng.'],
  ['Sale xác nhận, làm rõ', 'Trao đổi chi tiết, làm rõ nhu cầu, phạm vi và các yêu cầu cụ thể, chuyển giao cho PM.'],
  ['PM phân loại, giao task', 'Phân tích, đánh giá, chia dự án cho các bộ phận liên quan và lên kế hoạch triển khai.'],
  ['Sản xuất thực hiện', 'Triển khai sản xuất nội dung, thiết kế, dựng video, chạy quảng cáo theo kế hoạch đã thống nhất.'],
  ['PM duyệt nội bộ', 'Kiểm tra chất lượng, rà soát và trình duyệt nội dung, sản phẩm với ban lãnh đạo.'],
  ['Sales gửi khách', 'Bàn giao sản phẩm, đối soát kế hoạch và hỗ trợ khách hàng trong quá trình thực hiện.'],
  ['Đăng bài, nghiệm thu', 'Đăng tải nội dung, theo dõi hiệu quả, tiến hành nghiệm thu và báo cáo kết quả cho khách hàng.'],
];
// V0.7: bản rút gọn cho trang Về chúng tôi (nội dung lấy từ STORY phía trên)
export const MILES = [
  { yr: '2023', k: 'Khởi nguồn', t: '3 người trẻ và một câu hỏi lớn', d: 'Từ những cuộc trò chuyện về một đội ngũ Marketing đủ hiểu Hải Phòng.', img: 'team-field' },
  { yr: '9/2025', k: 'Thành lập', t: 'Trở thành một cái tên', d: 'Đất Cảng Agency ra đời với 4 người trong căn phòng 40m².', img: 'shopfront' },
  { yr: '11/2025', k: 'Mái nhà mới', t: 'Gần 20 người, một nhịp', d: 'Chuyển sang không gian rộng mở hơn, lớn lên cùng trách nhiệm.', img: 'team-meeting' },
  { yr: '8/2026', k: 'Trưởng thành', t: 'Người đồng hành chiến lược', d: 'Gắn liền với sự sống còn và thịnh vượng của doanh nghiệp.', img: 'team-office' },
];
export const VISION_SHORT = 'Agency Marketing chiến lược và thực thi uy tín hàng đầu.';
export const VISION_SUB = 'Người đồng hành đáng tin cậy của doanh nghiệp trên hành trình xây dựng thương hiệu và tăng trưởng bền vững.';
export const PROCESS_SHORT = ['Khách gửi yêu cầu', 'Sale làm rõ', 'PM giao task', 'Sản xuất', 'PM duyệt nội bộ', 'Gửi khách', 'Nghiệm thu'];
