import { PILLARS } from '../data/pillars.js';
import { CASES } from '../data/cases.js';
import { SITE } from '../data/site.js';
// Sitemap tự viết (không thêm gói). Không liệt kê trang khung /kien-thuc/ và /tuyen-dung/ (noindex).
export function GET() {
  const paths = ['/', '/ve-chung-toi/', '/dich-vu/', ...PILLARS.map((p) => `/dich-vu/${p.slug}/`), '/du-an/', ...CASES.map((c) => `/du-an/${c.slug}/`), '/bang-gia/', '/lien-he/'];
  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${paths.map((p) => `  <url><loc>${SITE.url}${p}</loc></url>`).join('\n')}\n</urlset>\n`;
  return new Response(xml, { headers: { 'Content-Type': 'application/xml' } });
}
