import { defineConfig } from 'astro/config';

// Không đặt `base`: site chạy ở tên miền riêng datcanggroup.vn (public/CNAME).
export default defineConfig({
  site: 'https://datcanggroup.vn',
  trailingSlash: 'always',
  build: { format: 'directory' },
  devToolbar: { enabled: false },
});
